$(function(){
  $(".button-collapse").sideNav();
});
